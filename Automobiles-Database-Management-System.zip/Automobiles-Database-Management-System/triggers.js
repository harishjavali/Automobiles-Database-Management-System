//var addcustomer=document.getElementById("addCusDet");
//addcustomer.onclick=function addCusDetails(){
 //   window.open("addcustomer.html");
}
var addcustomer=document.getElementById("addCarDet");
addcustomer.onclick=function addCusDetails(){
    window.open("addcardetail.html");
}
var addcustomer=document.getElementById("update");
addcustomer.onclick=function addCusDetails(){
    window.open("update.html");
}
var addcustomer=document.getElementById("details");
addcustomer.onclick=function addCusDetails(){
    window.open("details.html");
}
var addcustomer=document.getElementById("logout");
addcustomer.onclick=function addCusDetails(){
    window.open("login.html");
}