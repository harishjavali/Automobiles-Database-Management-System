var addcustomer=document.getElementById("bt1");
addcustomer.onclick=function addCusDetails(){
    window.open("http://localhost/showcars.php"");
}
var addcustomer=document.getElementById("bt2");
addcustomer.onclick=function addCusDetails(){
    window.open("q2.php");
}
var addcustomer=document.getElementById("bt3");
addcustomer.onclick=function addCusDetails(){
    window.open("q3.php");
}
var addcustomer=document.getElementById("bt4");
addcustomer.onclick=function addCusDetails(){
    window.open("q4.php");
}
var addcustomer=document.getElementById("bt5");
addcustomer.onclick=function addCusDetails(){
    window.open("q5.php");
}
var addcustomer=document.getElementById("bt6");
addcustomer.onclick=function addCusDetails(){
    window.open("q6.php");
}
var addcustomer=document.getElementById("bt7");
addcustomer.onclick=function addCusDetails(){
    window.open("q7.php");
}
var addcustomer=document.getElementById("bt8");
addcustomer.onclick=function addCusDetails(){
    window.open("q8.php");
}
var addcustomer=document.getElementById("bt9");
addcustomer.onclick=function addCusDetails(){
    window.open("q9.php");
}
var addcustomer=document.getElementById("bt10");
addcustomer.onclick=function addCusDetails(){
    window.open("q10.php");
}
var addcustomer=document.getElementById("bt11");
addcustomer.onclick=function addCusDetails(){
    window.open("q11.php");
}
var addcustomer=document.getElementById("bt12");
addcustomer.onclick=function addCusDetails(){
    window.open("q12.php");
}
var addcustomer=document.getElementById("bt13");
addcustomer.onclick=function addCusDetails(){
    window.open("q13.php");
}
var addcustomer=document.getElementById("bt14");
addcustomer.onclick=function addCusDetails(){
    window.open("q14.php");
}
var addcustomer=document.getElementById("bt15");
addcustomer.onclick=function addCusDetails(){
    window.open("q15.php");
}
var addcustomer=document.getElementById("bt16");
addcustomer.onclick=function addCusDetails(){
    window.open("q16.php");
}
var addcustomer=document.getElementById("bt17");
addcustomer.onclick=function addCusDetails(){
    window.open("q17.php");
}
var addcustomer=document.getElementById("gobackdetails");
addcustomer.onclick=function addCusDetails(){
    window.open("dashboard1.html");
}